function test(a, b, e)
    % TEST(a, b) prints an error message if "a" is not equal to "b"
    % TEST(a, b, e) prints an error message if the difference between
    %   "a" and "b" is not within epsilon "e" (used for float equality)
    
	 %{ 
	 (**) REMOVED 07/15/20 (**)
	  Reason: class(var) returns the data type of var as a CHAR, hence
	          class(5) == 'double' (that's the char array 'double').
	          Since char arrays of difference dimensions can not be
	          compared in a condional, i.e. 'word' == 'words' because
	          'word' is 1x4 and 'words' is 1x5, comparing two data
	          types via the "class" function is unsafe, for example
				 class(5) == class({5}) is the same as 'double' == 'cell'
    % variables a and b must be of the same type to be compared
	 if class(a) ~= class(b)
        disp("""" + a + """ is not the same type as """ + b + '"');
        return;
	 end
	 (**) REMOVED 07/15/20 (**)
	 %}
    
    % for floating point (decimal) comparisons with tolerances
    if nargin == 3
        if ~isnumeric(a) || ~isnumeric(b) || ~isnumeric(e)
            disp('"a" "b" and "e" must be numeric if specifying an '...
                + 'epsilon "e"');
            return;
        end
        % accept test between "a" and "b" if their distance is within "e"
        if abs((a)-(b)) <= e
            return;
        end
    end
        
    % accept/pass equality test between "a" and "b" before printing an error
    if isequal(a, b)
        return;
    end
    
    % print error since "a" and "b" did not pass equality/epsilon tests
    if exist("e","var")
        error_message(a, b, e);
    else
        error_message(a, b);
    end
end
