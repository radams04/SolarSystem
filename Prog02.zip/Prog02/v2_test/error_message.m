function error_message(a, b, e)
	% ERROR_MESSAGE(a, b, e) is a helper function for the "test" function
	% by printing an error message describing the inequality of "a" and "b"
	%
	%   (see "test.m" for more info)
    
	% get info (line_num, file_name, etc) about the test
	stack_trace = dbstack();
	if length(stack_trace) > 2
		 stack_trace = stack_trace(3);
	else 
		 % i.e. test() is called from the command window
		 stack_trace = {};
		 stack_trace.line = 0;
		 stack_trace.file = "command window";
	end

	format compact;
	format longG;
	fprintf(1,"-------------------------------------------\n");
	fprintf(1,"test failed at line %d", stack_trace.line);
	fprintf(1," of ""%s""\n", stack_trace.file);
	fprintf(1,"    ");
    disp(a);
    if nargin == 3
		 disp(" is not within " + e + " epsilon to");
	else
		 fprintf(1," !=\n");
    end
    fprintf(1,"    ");
	disp(b);

	% uncomment for exact floating point (decimal) representation
	%if isnumeric(a) && isnumeric(b)
		 %fprintf(1,"a: %0.55f\n",a);
		 %fprintf(1,"b: %0.55f\n",b);
	%end    

	fprintf(1,"-------------------------------------------\n");
end
