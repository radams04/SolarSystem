% test script

% Tests for getdist from planet to sun.
test(getdist(10,"neptune"), 29.7475069571019, 0.01)
test(getdist(3000,"earth"), 0.979028840390823, 0.01)

% Tests for getdist of planet at different days.
test(getdist(2:4,"earth"), 1.00263672431945, 0.01)
test(getdist([3:5 10],"neptune"), 29.7475447263961, 0.01)

% Tests the distance of one planet to the other.
test(getdist(400:404,"mars","venus"), 1.25216806150173, 0.01)
test(getdist([5:7 300:310],"mercury","saturn"), 10.0962657472462, 0.01)
test(getdist(300:308,"pluto","pluto"), 0.0193254239922058, 0.01)
test(getdist([35:40 1000:1001],"earth","earth"),  0.136568594824752, 0.01)

% Tests for getaxes major and minor axes.
[a,b] = getaxes("mercury");
test(a, 0.773827585688828, 0.01);
test(b, 0.614690313550653, 0.01);
[a,b] = getaxes("pluto");
test(a, 79.0600005432719, 0.01);
test(b, 59.4531210324677, 0.01);

% Tests for getaxes semi major and minor axes.
[a,b] = getaxes("mars","semi");
test(a, 1.52398897068393, 0.01);
test(b, 1.38226588823216, 0.01);
[a,b] = getaxes("saturn","semi");
test(a, 9.52899935597, 0.01);
test(b, 9.01443387829, 0.01);

% Test cases for period function (pd). 
[period,i] = pd("venus");
test(period,225);
test(i,3);
[period,i] = pd("neptune");
test(period,59860);
test(i,15);

% Test cases for getdist helper function: pointfunc.
test(pointfunc(50,"earth"),[0.656878,0.730405]);
test(pointfunc(50:100,"pluto"),[28.442177,-39.391542]);

%% Justin Morgan's Assigned Test Cases
% getdist
test(getdist(10,"neptune"),29.7475069571019,0.000001);
test(getdist(3000,"earth"),0.979028840390823,0.000001);
test(getdist(2:4,"earth"),1.00263672431945,0.000001);
test(getdist([3:5 10],"neptune"),29.7475447263961,0.000001);
test(getdist(400:404,"mars","venus"),0.781720819569603,0.000001);
test(getdist([5:7 300:310],"mercury","saturn"),9.61167514532312,0.000001);
test(getdist(300:308,"pluto","pluto"),0.0193254239922058,0.000001);
test(getdist([35:40 1000:1001],"earth","earth"),0.102422814642191,0.000001);

% getaxes
[a,b] = getaxes("jupiter");
test(a,10.4059982519322,0.01);
test(b,9.90651154132498,0.01);
[a,b] = getaxes("pluto");
test(a,79.0600005432719,0.01);
test(b,59.4531210324677,0.01);
[a,b] = getaxes("mercury");
test(a,0.773827585688828,0.01);
test(b,0.614690313550653,0.01);
[a,b] = getaxes("mars","semi");
test(a,1.52398897068393,0.01);
test(b,1.38226588823216,0.01);
[a,b] = getaxes("saturn");
test(a,19.0579987119355,0.01);
test(b,18.0288677565864,0.01);





