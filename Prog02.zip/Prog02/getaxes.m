function [a,b] = getaxes(varargin)
%
% GETAXES(planet, option) returns the scalars 'a' and 'b' that
%   corresponds to the major and minor axes of the 'orbit'
%
%     'orbit' is a string that represents a name of a planet (9 possible):
%       "jupiter" or "mercury" or "saturn" ...
%     'option' is an optional argument that (if used) is the string "semi"
%       that sets the GETAXES return to be semi-major and semi-minor axes
%
%   examples:
%     GETAXES("earth","semi") == 1  (that is one AU)
%     [a, b] = GETAXES("jupiter");
%       where 'a' and 'b' are the major and minor axes of jupiter's orbit
orbits = readmatrix('orbits.csv'); 
data = orbits'; 
orbit = varargin{1};
[period,i] = pd(orbit);
for x = 1:(ceil(period/2))
    pointA = data(x,i:(i+1)); 
    pointB = data((ceil((period)/2) + (x-1)),i:(i+1)); 
    dist(x) = sqrt( (((pointB(2)) - (pointA(2)))^2) + (((pointB(1)) - (pointA(1)))^2) );
end
dist = dist';
switch nargin
    case 2
        option = varargin{2};
    case 1
        option = "none";
end
if contains(option,"semi",'IgnoreCase',true)
    b = min(dist)/2; 
    a = max(dist)/2;
else
    b = min(dist); 
    a = max(dist); 
end
end
