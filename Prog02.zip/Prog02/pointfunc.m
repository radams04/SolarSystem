function x = pointfunc(varargin)
% Function takes the inputs of days and planet. It outputs the planet position on
% that day or the average position of the planet on several days.
orbits = readmatrix('orbits.csv');
data = orbits';
d = zeros(9,1);
days = varargin{1};
planetA = varargin{2};
if numel(days) > 1
    unit_days = numel(days);
else
    unit_days = days;
end
for i = 1:9
    period = sum(~isnan(data(:,i)));
    d(i) = unit_days;
    while d(i) > period
        d(i) = d(i) - period;
    end
    if planetA == "mercury" && i==1
        x = [data(d(i),2*i-1),data(d(i), 2*i)];
    elseif planetA == "venus" && i==2
        x = [data(d(i),2*i-1),data(d(i), 2*i)];
    elseif planetA == "earth" && i==3
        x = [data(d(i),2*i-1),data(d(i), 2*i)];
    elseif planetA == "mars" && i==4
        x = [data(d(i),2*i-1),data(d(i), 2*i)];
    elseif planetA == "jupiter" && i==5
        x = [data(d(i),2*i-1),data(d(i), 2*i)];
    elseif planetA == "saturn" && i==6
        x = [data(d(i),2*i-1),data(d(i), 2*i)];
    elseif planetA == "uranus" && i==7
        x = [data(d(i),2*i-1),data(d(i), 2*i)];
    elseif planetA == "neptune" && i==8
        x = [data(d(i),2*i-1),data(d(i), 2*i)];
    elseif planetA == "pluto" && i==9
        x = [data(d(i),2*i-1),data(d(i), 2*i)];
    end
end
end