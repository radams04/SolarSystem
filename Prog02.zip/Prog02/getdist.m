function ave_distance = getdist(varargin)
% GETDIST(days, planetA, planetB) returns the average distance from
%   'planetA' to 'planetB' during all specified 'days'
%
%      'planetA' and 'planetB' are strings that specify which planet
%        i.e. "pluto" or "mars". If only one string is passed, meaning
%        only 'planetA' is specified, than the distance is calculated
%        between 'planetA' and the sun. If 'planetA' is equal to
%        'planetB', than the distance 'planetA' travels on its orbit
%        during 'days' is calculated.
%
%      'days' is a single-dimension array of positive whole number(s)
%        that specify the day(s) this distance is calculated.
days = varargin{1};
planetA = varargin{2};
unit_days = numel(days);
switch nargin
    case 3
        planetB = varargin{3};
    case 2
        planetB = "none";
end
if contains(planetB,"none")
    planet_to_sun = pointfunc(days,planetA);
    distance = sqrt((planet_to_sun(1))^2+(planet_to_sun(2))^2);
else
    if strcmpi(planetA, planetB)
        period = pd(planetA);
        [a,b] = getaxes(planetA,"semi");
        circ = (2*pi*sqrt(((a^2)+(b^2))/2));
        distance = circ*(unit_days/period);
    elseif ~strcmpi(planetA, planetB)
        Apoint = pointfunc(days,planetA);
        Bpoint = pointfunc(days,planetB);
        distance = sqrt(((Bpoint(2)-Apoint(2))^2) + ((Bpoint(1)-Apoint(1))^2));
    end
end
ave_distance = distance;
end