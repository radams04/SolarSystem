function [period,i] = pd(planetA)
% pd(PlanetA) returns the period of a certain planet and its column assignment: i.
orbits = readmatrix('orbits.csv');
data = orbits';
if planetA == "mercury"
    i = 1;
elseif planetA == "venus"
    i = 3;
elseif planetA == "earth"
    i = 5;
elseif planetA == "mars"
    i = 7;
elseif planetA == "jupiter"
    i = 9;
elseif planetA == "saturn"
    i = 11;
elseif planetA == "uranus"
    i = 13;
elseif planetA == "neptune"
    i = 15;
elseif planetA == "pluto"
    i = 17;
end
period = sum(~isnan(data(:,i)));
end