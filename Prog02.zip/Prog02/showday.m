function showday(planets, day)
	% SHOWDAY(planets, day) displays all of the 'planets' in their orbital
	%   position(s) on for the specific 'day'
	%
	%     'planets' is a single-dimension string array that contains any
	%       of the planets: "mars" and/or "jupiter" and/or ...
	%     'day' is a positive whole number that specifies what day/state 
	%       of all of the planets are positioned
	%
	%   example:
	%     showday(["neptune" "saturn" "pluto"], 1500)
	%
	%   NOTE: you only need to plot the planets' position(s) on that 'day'
orbits = readmatrix('orbits.csv'); 
data = orbits';
plot(data(:,1:2:end),data(:,2:2:end)); 
hold on
plot(0,0,'r*','markersize',5); 
for i = 1:9
    period = sum(~isnan(data(:,i))); d(i) = day; 
    while d(i) > period       
        d(i) = d(i) - period; 
    end
if contains("mercury",planets) && i==1
   plot(data(d(i),2*i-1), data(d(i), 2*i), 'mo'); 
   disp([data(d(i),1),data(d(i),2)]); 
elseif contains("venus",planets) && i==2
   plot(data(d(i),2*i-1), data(d(i), 2*i), 'mo'); 
   disp([data(d(i),3),data(d(i),4)]); 
elseif contains("earth",planets) && i==3
   plot(data(d(i),2*i-1), data(d(i), 2*i), 'mo'); 
    disp([data(d(i),5),data(d(i),6)]); 
elseif contains("mars",planets) && i==4
   plot(data(d(i),2*i-1), data(d(i), 2*i), 'mo'); 
   disp([data(d(i),7),data(d(i),8)]); 
elseif contains("jupiter",planets) && i==5
    plot(data(d(i),2*i-1), data(d(i), 2*i), 'mo');  
     disp([data(d(i),9),data(d(i),10)]); 
elseif contains("saturn",planets) && i==6
   plot(data(d(i),2*i-1), data(d(i), 2*i), 'mo'); 
    disp([data(d(i),11),data(d(i),12)]); 
elseif contains("uranus",planets) && i==7
   plot(data(d(i),2*i-1), data(d(i), 2*i), 'mo'); 
    disp([data(d(i),13),data(d(i),14)]); 
elseif contains("neptune",planets) && i==8
    plot(data(d(i),2*i-1), data(d(i), 2*i), 'mo'); 
     disp([data(d(i),15),data(d(i),16)]); 
elseif contains("pluto",planets) && i==9
    plot(data(d(i),2*i-1), data(d(i), 2*i), 'mo');  
     disp([data(d(i),17),data(d(i),18)]); 
end
end
end